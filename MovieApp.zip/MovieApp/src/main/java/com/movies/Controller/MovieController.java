package com.movies.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.movies.Repo.MovieRepository;
import com.movies.entity.Movie;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Controller
@RequestMapping("/movies")
public class MovieController {

    @Autowired
    private MovieRepository movieRepository;

    @GetMapping
    public String listMovies(Model model) {
        List<Movie> movies = movieRepository.findAll();
        model.addAttribute("movies", movies);
        return "movie/list";
    }

    @GetMapping("/create")
    public String createMovieForm(Model model) {
        model.addAttribute("movie", new Movie());
        return "movie/create";
    }

    @PostMapping("/create")
    public String createMovie(@ModelAttribute Movie movie) {
        movieRepository.save(movie);
        return "redirect:/movies";
    }

    @GetMapping("/edit/{id}")
    public String editMovieForm(@PathVariable Long id, Model model) {
        Movie movie = movieRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid movie Id:" + id));
        model.addAttribute("movie", movie);
        return "movie/edit";
    }

    @PostMapping("/edit/{id}")
    public String editMovie(@PathVariable Long id, @ModelAttribute Movie movie) {
        movie.setMovieId(id);
        movieRepository.save(movie);
        return "redirect:/movies";
    }

    @GetMapping("/delete/{id}")
    public String deleteMovie(@PathVariable Long id) {
        movieRepository.deleteById(id);
        return "redirect:/movies";
    }

    @GetMapping("/search")
    public String searchMovies(@RequestParam(name = "id", required = false) Long id,
                               @RequestParam(name = "name", required = false) String name,
                               Model model) {
        List<Movie> movies;

        if (id != null) {
            movies = List.of(movieRepository.findById(id).orElse(null));
        } else if (name != null) {
            movies = movieRepository.findByMovieNameContaining(name);
        } else {
            movies = movieRepository.findAll();
        }

        model.addAttribute("movies", movies);
        return "movie/list";
    }
}
